import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, Legend } from 'recharts';

function GraphCard({ title, subtitle, data, xKey, xLabel, lines, reference }) {
  return <article className="graph-card">
    <div className="graph-title"><div><h3>{title}</h3><p>{subtitle}</p></div></div>
    <div className="graph-wrap"><ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 12, right: 18, left: -10, bottom: 8 }}>
        <CartesianGrid stroke="#1b3045" strokeDasharray="3 3"/>
        <XAxis dataKey={xKey} stroke="#7790a8" tick={{ fill: '#8fa6bb', fontSize: 10 }} label={{ value: xLabel, position: 'insideBottom', offset: -2, fill: '#8fa6bb', fontSize: 10 }}/>
        <YAxis stroke="#7790a8" tick={{ fill: '#8fa6bb', fontSize: 10 }} width={48}/>
        <Tooltip contentStyle={{ background: '#0b1a2a', border: '1px solid #28425a', borderRadius: 8, color: '#e8f4ff', fontSize: 12 }}/>
        {reference && <ReferenceLine x={reference.x} stroke="#ffb76c" strokeDasharray="4 4" label={{ value: reference.label, fill: '#ffca91', fontSize: 10 }}/>}
        <Legend wrapperStyle={{ fontSize: 10, color: '#9fb2c6' }}/>
        {lines.map(line => <Line key={line.key} type="monotone" dataKey={line.key} name={line.name} stroke={line.color} strokeWidth={2.2} dot={false} activeDot={{ r: 4 }}/>)}
      </LineChart>
    </ResponsiveContainer></div>
  </article>;
}

export default function Graphs({ physics, params, data }) {
  const critical = physics.criticalAngle ?? 0;
  return <div className="graphs-grid">
    <GraphCard title="Internal angle vs ray outcome" subtitle="Schematic ray-model indicator, not a measured link transmission curve." data={data.angle} xKey="angle" xLabel="Incidence angle (°)" lines={[{ key: 'transmission', name: 'Guided / transmitted indicator (%)', color: '#5ee6ff' }]} reference={{ x: Math.round(critical / 5) * 5, label: 'Critical angle' }}/>
    <GraphCard title="Bend radius vs predicted bend loss" subtitle="Educational approximation; not a validated fibre-specific model." data={data.bend} xKey="radius" xLabel="Bend radius (model units)" lines={[{ key: 'loss', name: 'Bend loss (dB)', color: '#a8a2ff' }]}/>
    <GraphCard title="Fibre length vs received power" subtitle="Calculated from baseline attenuation and the current bend-loss setting." data={data.length} xKey="length" xLabel="Length (km)" lines={[{ key: 'power', name: 'Received power (mW)', color: '#63e5b6' }]}/>
    <GraphCard title="Input power vs received power" subtitle="Same total link loss as the current dashboard parameters." data={data.power} xKey="input" xLabel="Input power (mW)" lines={[{ key: 'output', name: 'Received power (mW)', color: '#ffbd7c' }]}/>
    <GraphCard title="Curvature vs received power" subtitle="Uses the same educational bend-loss approximation as the readout." data={data.curvature} xKey="severity" xLabel="Bend severity (model units)" lines={[{ key: 'power', name: 'Received power (mW)', color: '#5ee6ff' }]}/>
    <GraphCard title="Baseline attenuation vs received power" subtitle="Power is calculated using α × L in dB." data={data.attenuation} xKey="attenuation" xLabel="Attenuation (dB/km)" lines={[{ key: 'output', name: 'Received power (mW)', color: '#a8a2ff' }]}/>
  </div>;
}