import React, { useMemo, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html, Line, Environment } from '@react-three/drei';
import * as THREE from 'three';

function pathPoints(bend, curvature, controlPoints) {
  const pts = [];
  for (let i = 0; i <= 100; i++) {
    const t = i / 100, x = -4 + 8 * t;
    let y = 0;
    if (bend) y = curvature * Math.sin(t * Math.PI * 2) * Math.sin(t * Math.PI);
    if (controlPoints?.length === 3) {
      const [a, b, c] = controlPoints;
      const u = 1 - t;
      y = u*u*u*a + 3*u*u*t*b + 3*u*t*t*c;
    }
    pts.push(new THREE.Vector3(x, y, 0));
  }
  return pts;
}

function Fibre({ bend, curvature, controlPoints, onControlPointChange, showCore, showCladding, showRay, angle, criticalAngle, rayMode }) {
  const pulse = useRef();
  const escaped = useRef();
  const activeControls = bend ? (controlPoints ?? [-curvature * .35, curvature, -curvature * .35]) : null;
  const points = useMemo(() => pathPoints(bend, curvature, activeControls), [bend, curvature, activeControls]);
  const curve = useMemo(() => new THREE.CatmullRomCurve3(points), [points]);
  const coreGeo = useMemo(() => new THREE.TubeGeometry(curve, 120, .115, 12, false), [curve]);
  const cladGeo = useMemo(() => new THREE.TubeGeometry(curve, 120, .23, 16, false), [curve]);
  const rayPoints = useMemo(() => {
    const result = [];
    const n = 22;
    for (let i = 0; i <= n; i++) {
      const t = i / n, base = curve.getPoint(t);
      const offset = (i % 2 ? .09 : -.09);
      result.push(new THREE.Vector3(base.x, base.y + offset, .015));
    }
    return result;
  }, [curve]);
  const rayStatus = angle > criticalAngle ? 'TIR' : angle < criticalAngle ? 'REFRACTION' : 'CRITICAL';
  useFrame(({ clock }) => {
    if (pulse.current) {
      const t = (clock.getElapsedTime() * .12) % 1;
      const p = curve.getPoint(t);
      pulse.current.position.set(p.x, p.y, .04);
    }
    if (escaped.current) {
      escaped.current.position.set(.5, .25 + Math.sin(clock.getElapsedTime() * 2) * .08, .15);
    }
  });
  return <group>
    {showCladding && <mesh geometry={cladGeo}><meshPhysicalMaterial color="#7787ff" transparent opacity={.22} roughness={.18} metalness={.25} transmission={.15} thickness={.3}/></mesh>}
    {showCore && <mesh geometry={coreGeo}><meshPhysicalMaterial color="#31d8ff" emissive="#0c9fce" emissiveIntensity={.5} transparent opacity={.66} roughness={.2}/></mesh>}
    {showRay && <Line points={rayPoints} color={rayStatus === 'TIR' ? '#d5ffff' : '#ff9a91'} lineWidth={2} transparent opacity={.95}/>}
    {showRay && <mesh ref={pulse}><sphereGeometry args={[.085, 18, 18]}/><meshBasicMaterial color="#e4ffff"/></mesh>}
    {showRay && rayMode === 'manual' && angle < criticalAngle && <mesh ref={escaped}><sphereGeometry args={[.055, 12, 12]}/><meshBasicMaterial color="#ff9a91"/></mesh>}
    {bend && activeControls && activeControls.map((y, i) => <mesh key={i} position={[-2.67 + i * 2.67, y, .25]}
      onPointerOver={e => { e.stopPropagation(); document.body.style.cursor = 'ns-resize'; }}
      onPointerOut={() => { document.body.style.cursor = 'default'; }}
      onPointerDown={e => { e.stopPropagation(); e.target.setPointerCapture?.(e.pointerId); }}
      onPointerUp={e => { e.stopPropagation(); }}
      onPointerMove={e => { if (e.buttons === 1 && onControlPointChange) { e.stopPropagation(); onControlPointChange(i, THREE.MathUtils.clamp(e.point.y, -.85, .85)); } }}>
      <sphereGeometry args={[.105, 18, 18]}/><meshStandardMaterial color="#ffcb7d" emissive="#ff9d43" emissiveIntensity={.55}/>
    </mesh>)}
    <mesh position={[-4.55, 0, 0]} rotation={[0, 0, Math.PI/2]}><cylinderGeometry args={[.32, .32, .72, 32]}/><meshStandardMaterial color="#233b55" metalness={.8} roughness={.25}/></mesh>
    <mesh position={[-4.17, 0, 0]}><sphereGeometry args={[.17, 20, 20]}/><meshBasicMaterial color="#ff688b" emissive="#ff2c70" emissiveIntensity={1.5}/></mesh>
    <mesh position={[4.55, 0, 0]} rotation={[0, 0, Math.PI/2]}><cylinderGeometry args={[.32, .32, .72, 32]}/><meshStandardMaterial color="#233b55" metalness={.8} roughness={.25}/></mesh>
    <mesh position={[4.16, 0, 0]}><sphereGeometry args={[.16, 20, 20]}/><meshBasicMaterial color="#858dff" emissive="#4d50ff" emissiveIntensity={.8}/></mesh>
    <Html position={[-4.5, .63, 0]} center distanceFactor={10}><div className="scene-label">LASER SOURCE</div></Html>
    <Html position={[0, .72, 0]} center distanceFactor={10}><div className="scene-label">CORE + CLADDING</div></Html>
    <Html position={[4.5, .63, 0]} center distanceFactor={10}><div className="scene-label">PHOTODETECTOR</div></Html>
    <Html position={[0, -1.05, .1]} center distanceFactor={10}><div className={`ray-status ${rayStatus.toLowerCase()}`}>{rayStatus === 'TIR' ? 'TOTAL INTERNAL REFLECTION' : rayStatus === 'CRITICAL' ? 'CRITICAL CONDITION' : 'RAY MAY REFRACT / ESCAPE'}</div></Html>
  </group>;
}

export default function FibreScene(props) {
  return <Canvas camera={{ position: [0, 3.5, 9], fov: 43 }} dpr={[1, 1.75]}>
    <color attach="background" args={['#07111f']}/>
    <fog attach="fog" args={['#07111f', 11, 23]}/>
    <ambientLight intensity={1.2}/>
    <directionalLight position={[4, 7, 5]} intensity={2.3} color="#b7e9ff"/>
    <pointLight position={[0, 1, 1]} intensity={16} color="#29cfff" distance={10}/>
    <gridHelper args={[13, 32, '#21445b', '#132c41']} position={[0, -.8, 0]}/>
    <Fibre {...props}/>
    <OrbitControls makeDefault enableDamping minDistance={5} maxDistance={15} maxPolarAngle={Math.PI * .82}/>
  </Canvas>;
}